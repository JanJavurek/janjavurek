//
//  CollectionViewController.swift
//  CGISampleProject
//
//  Created by Jan Javůrek on 05.03.19.
//  Copyright © 2019 jjsoft. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    struct myCollectionItem {
        var tile: String
        var image: String
        var text: String
    }
    var myCollectionItems: [myCollectionItem] = []
    var myCollectionView: UICollectionView!
    var cellId = "Cell"
 
    override func viewDidLoad() {
        super.viewDidLoad()
        setObjects()
        fillData()
    }
    
    func setObjects() {
        //Set Layout for myCollectionView
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 15, left: 5, bottom: 15, right: 5)
        layout.itemSize = CGSize(width: 140, height: 140)
        layout.scrollDirection = .horizontal
        
        //Set myCollectionView
        myCollectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        myCollectionView.dataSource = self
        myCollectionView.delegate = self
        myCollectionView.register(MyCell.self, forCellWithReuseIdentifier: cellId)
        myCollectionView.backgroundColor = .white
        self.view.addSubview(myCollectionView)
    }
    
    func fillData() {
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 1", image: "01", text: "Doprovodný text k 1. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 2", image: "02", text: "Doprovodný text k 2. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 3", image: "03", text: "Doprovodný text k 3. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 4", image: "04", text: "Doprovodný text k 4. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 5", image: "05", text: "Doprovodný text k 5. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 6", image: "06", text: "Doprovodný text k 6. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 7", image: "07", text: "Doprovodný text k 7. obrázku"))
        myCollectionItems.append(myCollectionItem(tile: "Nadpis 8", image: "08", text: "Doprovodný text k 8. obrázku"))
    }
        
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.myCollectionItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! MyCell
        cell.backgroundColor = .white
        cell.topicLabel.text = self.myCollectionItems[indexPath.item].tile
        cell.pictureImageView.image = UIImage(named: self.myCollectionItems[indexPath.item].image)
        cell.shortTextLabel.text = self.myCollectionItems [indexPath.item].text
        return cell
    }
}

class MyCell: UICollectionViewCell {
    
    let topicLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.backgroundColor = .white
        label.font = UIFont.systemFont(ofSize: 16)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
        
    let pictureImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.backgroundColor = .white
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
        
    let shortTextLabel: UILabel = {
        let label = UILabel()
        label.textColor = .darkGray
        label.backgroundColor = .white
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 12)
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
        
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubViews()
    }
        
    func addSubViews() {
        backgroundColor = .white
        
        addSubview(topicLabel)
        addSubview(pictureImageView)
        addSubview(shortTextLabel)
        
        //Constraints for items in CollectionViewCell
        topicLabel.leftAnchor.constraint(equalTo: leftAnchor, constant: 5).isActive = true
        topicLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: -5).isActive = true
        
        pictureImageView.topAnchor.constraint(equalTo: topicLabel.bottomAnchor, constant: 5).isActive = true
        pictureImageView.widthAnchor.constraint(equalTo: widthAnchor).isActive = true
        pictureImageView.heightAnchor.constraint(equalToConstant: 80).isActive = true
        
        shortTextLabel.topAnchor.constraint(equalTo: pictureImageView.bottomAnchor, constant: 5).isActive = true
        shortTextLabel.leftAnchor.constraint(equalTo: topicLabel.leftAnchor).isActive = true
        shortTextLabel.rightAnchor.constraint(equalTo: topicLabel.rightAnchor).isActive = true
    }
        
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
