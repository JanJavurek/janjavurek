//
//  MyTabBarControllerViewController.swift
//  CGISampleProject
//
//  Created by Jan Javůrek on 05.03.19.
//  Copyright © 2019 jjsoft. All rights reserved.
//

import UIKit

class MyTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Tab 1
        let tabOne = NotesViewController()
        let tabOneBarItem = UITabBarItem(title: "Poznámky", image: UIImage(named: "icon-note.png"), selectedImage: UIImage(named: "icon-note.png"))
        tabOne.tabBarItem = tabOneBarItem
    
        //Tab 2
        let tabTwo = CollectionViewController()
        let tabTwoBarItem = UITabBarItem(title: "Kolekce", image: UIImage(named: "icon-collection.png"), selectedImage: UIImage(named: "icon-collection.png"))
        tabTwo.tabBarItem = tabTwoBarItem
        
        let controllerArray = [tabOne, tabTwo]
        
        self.viewControllers = controllerArray.map{ UINavigationController.init(rootViewController: $0)}
        self.navigationItem.title = "CGI - ukázková aplikace"
    }
}
