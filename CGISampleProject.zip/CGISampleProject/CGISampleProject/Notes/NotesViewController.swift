//
//  NotesViewController.swift
//  CGISampleProject
//
//  Created by Jan Javůrek on 05.03.19.
//  Copyright © 2019 jjsoft. All rights reserved.
//

import UIKit

class NotesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    struct myNote {
        var text: String
    }
    var myNotes: [myNote] = []
    var myButtonAdd: UIButton = UIButton()
    var myTableView: UITableView = UITableView()
    let cellId = "Cell"
  
    override func viewDidLoad() {
        super.viewDidLoad()
        setObjects()
        fillData()
    }
    
    func setObjects() {
        //Get main screen bounds
        let screenSize: CGRect = UIScreen.main.bounds
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        let screenYOffset = UIApplication.shared.statusBarFrame.height + (self.navigationController?.navigationBar.frame.size.height ?? 0)
        
        //Add button
        myButtonAdd.frame = CGRect(x: 0, y: screenYOffset, width: screenWidth, height: 30)
        myButtonAdd.setTitleColor(.blue, for: .normal)
        myButtonAdd.backgroundColor = .white
        myButtonAdd.setTitle("Přidat", for: .normal)
        myButtonAdd.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(myButtonAdd)
        
        //Add tableView
        myTableView.frame = CGRect(x: 0, y: screenYOffset + 30, width: screenWidth, height: screenHeight - screenYOffset - 30);
        myTableView.dataSource = self
        myTableView.delegate = self
        myTableView.estimatedRowHeight = 40.0
        myTableView.rowHeight = UITableView.automaticDimension
        myTableView.register(UITableViewCell.self, forCellReuseIdentifier: cellId)
        //To remove extra lines at the end of the table
        myTableView.tableFooterView = UIView()
        self.view.addSubview(myTableView)
    }
    
    func fillData() {
        myNotes.append(myNote(text: "Dojít nakoupit chleba a rohlíky."))
        myNotes.append(myNote(text: "Naplánovat večeři s rodinou a pozvat rodinu Novákových, Bohatých a Veselých."))
        myNotes.append(myNote(text: "Zajet autem do myčky v Břeclavi a vysát interiér."))
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myNotes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath)
        cell.textLabel?.text = self.myNotes[indexPath.row].text
        cell.textLabel?.numberOfLines = 0
        return cell
    }
    
    @objc func buttonAction() {
        //To add note
        let alert = UIAlertController(title: "", message: "Zadejte poznámku", preferredStyle: .alert)
        alert.addTextField(configurationHandler: { (textField) in
            textField.text = ""
        })
        alert.addAction(UIAlertAction(title: "Uložit", style: .default, handler: { (updateAction) in
            self.myNotes.append(myNote(text: alert.textFields!.first!.text!))
            self.myTableView.reloadData()
        }))
        alert.addAction(UIAlertAction(title: "Zrušit", style: .cancel, handler: nil))
        self.present(alert, animated: false)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        //To update note
        let editAction = UITableViewRowAction(style: .default, title: "Upravit", handler: { (action, indexPath) in
            let alert = UIAlertController(title: "", message: "Upravte poznámku", preferredStyle: .alert)
            alert.addTextField(configurationHandler: { (textField) in
                textField.text = self.myNotes[indexPath.row].text
            })
            alert.addAction(UIAlertAction(title: "Upravit", style: .default, handler: { (updateAction) in
                self.myNotes[indexPath.row].text = alert.textFields!.first!.text!
                self.myTableView.reloadRows(at: [indexPath], with: .fade)
            }))
            alert.addAction(UIAlertAction(title: "Zrušit", style: .cancel, handler: nil))
            self.present(alert, animated: false)
        })
        editAction.backgroundColor = UIColor.blue
        //To delete note
        let deleteAction = UITableViewRowAction(style: .default, title: "Smazat", handler: { (action, indexPath) in
            self.myNotes.remove(at: indexPath.row)
            tableView.reloadData()
        })
        deleteAction.backgroundColor = UIColor.red
    
        return [deleteAction, editAction]
    }
}
